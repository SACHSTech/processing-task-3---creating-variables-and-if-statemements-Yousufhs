import processing.core.PApplet;

public class Sketch extends PApplet {
	
	
  /**
   * Called once at the beginning of execution, put your size all in this method
   */
  public void settings() {
	// put your size call here
    size(600, 600);
  }

  /** 
   * Called once at the beginning of execution.  Add initial set up
   * values here i.e background, stroke, fill etc.
   */
  public void setup() {
    background(210, 255, 173);
  }

  /**
   * Called repeatedly, anything drawn to the screen goes here
   */
  public void draw() {
    stroke(255);
    background(3,211, 252);
    fill(74, 243, 255);

    float score = 89;
    boolean isGradeA = score >=90; 
    if (isGradeA) {
    background (96, 155, 168);
    fill(0);
    }

    fill(0, 0, 0);
    rect(0, 280, 1000, 600);

    ellipse(310, 266, 45, 45);
    fill(0, 0, 0); 

    ellipse(310, 266, 45, 45); 
    fill(0, 0, 0);

    ellipse(190, 265, 45, 45);
    fill(0, 0,0);

    ellipse(190, 265, 45, 45); 
    fill(235, 228, 228);

    rect(150, 145, 200, 100);
    fill(235, 228, 228);
 
    rect(650, 0, 100, 500);
    fill(255, 255, 255);

    rect(85, 180, 65, 65);

    fill(255, 234, 0);
    ellipse(570, 0, 140, 140);

    fill(255, 235, 15);
    rect(0, 345, 700, 25);

    fill(168, 167, 157);
    ellipse(310, 266, 25, 25); 

    fill(168, 167, 157);
    ellipse(190, 265, 25, 25);

    fill(117, 241, 255);
    rect(85, 180, 35, 35);

    fill(250, 238, 17);
    rect(85, 220, 15, 25);

    //clouds
    fill(255, 255, 255);
    ellipse(100, 40, 125, 50);

    fill(255, 255, 255);
    ellipse(300, 40, 125, 50);

    time();
  }
    private void time() {
      int s = second();  // Values from 0 - 59
      int m = minute();  // Values from 0 - 59
      int h = hour();    // Values from 0 - 23
      text(+s, 40, 10);
      text(+m, 20, 10);
      text(+h, 10, 10);
    }


}